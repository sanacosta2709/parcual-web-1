export const environment = {
  production: false,
  baseUrl: 'https://fakestoreapi.com',
};
